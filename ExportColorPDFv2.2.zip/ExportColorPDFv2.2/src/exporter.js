import { NativeModules } from 'react-native';
import {
  FileUtils,
  PluginCommAPI,
  PluginDocAPI,
  PluginFileAPI,
  PluginManager,
  PluginNoteAPI,
} from 'sn-plugin-lib';

// ─── Tunables ─────────────────────────────────────────────────────────────────
const MAX_PAGES = 0;                 // 'full' mode: 0 = every page

// The six highlighter colours (CustomColorPalette "Highlighter …" entries).
// Wash-vs-opaque is colour-driven: a highlighter colour on a wash-capable pen →
// translucent wash; any other colour → opaque.
const HIGHLIGHTER_HEXES = new Set(
  ['#F2C6DE', '#FAEDCB', '#F7D9C4', '#C6DEF1', '#C9E4DE', '#DBCDF0'],
);
function isHighlightColor(hex) { return !!hex && HIGHLIGHTER_HEXES.has(hex.toUpperCase()); }

// Wash-capable pens: the marker (penType 11). Pen(10)/calligraphy(15)/ink(16)
// always render opaque. See [[exportcolorpdf-plugin]].
const WASH_PEN_TYPES = new Set([11 /* marker */]);

// ─── Helpers ─────────────────────────────────────────────────────────────────

function deriveBaseName(notePath) {
  const last  = notePath.split('/').pop() || 'doc';
  const noExt = last.replace(/\.[^.]+$/, '');
  return noExt.replace(/[^A-Za-z0-9._-]+/g, '_').replace(/^_+|_+$/g, '') || 'doc';
}
function isArgbColor(penColor) { return penColor > 255 || penColor < 0; }
// Native (non-plugin) greyscale pens store penColor as a 0-255 grayscale level.
// On DOCS the base render has no ink, so an uncoloured native stroke must be
// drawn in its own grey — otherwise light/dark grey come out solid black. Map the
// level straight to an RGB grey; out-of-range (shouldn't happen here) → black.
function greyFromPenColor(pc) {
  if (typeof pc === 'number' && pc >= 0 && pc <= 255) {
    const h = (pc & 0xFF).toString(16).padStart(2, '0');
    return `#${h}${h}${h}`;
  }
  return '#000000';
}
function argbToHex(argb) {
  const u = argb >>> 0;
  const r = (u >> 16) & 0xFF, g = (u >> 8) & 0xFF, b = u & 0xFF;
  return `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}`;
}
async function settle(promise) {
  try { return { ok: true, val: await promise, err: null }; }
  catch (e) { return { ok: false, val: null, err: e instanceof Error ? e.message : String(e) }; }
}
function unpack(resp) {
  if (resp && typeof resp === 'object' && 'success' in resp) {
    if (resp.success) return { ok: true, val: resp.result, err: null };
    return { ok: false, val: null, err: (resp.error && resp.error.message) || 'success=false' };
  }
  return { ok: true, val: resp, err: null };
}

// Geometry fingerprint of a stroke — a DURABLE colour key that survives note
// editing (reorder/insert of OTHER strokes) where numInPage drifts and the uuid
// is re-minted. MUST be computed byte-identically to CustomColorPalette's
// _strokeGeomKey (index.js) — keep the two in sync. Read async (only a few reads).
async function strokeGeomKey(el) {
  // Durable per-stroke key. The old 5-point version COLLIDED for short strokes
  // (single letters) → colours bled between strokes. Strengthened: native pen
  // identity (penColor+penType) + point count + up to 9 evenly-spaced sample
  // points + the real bbox of those points. Two distinct strokes (different pen,
  // length, position OR size) can no longer share a key. We deliberately do NOT
  // use el.maxX/maxY — for document annotations those are the PAGE bounds
  // (15819,11864 EMR), constant. MUST match CCP _strokeGeomKey byte-for-byte.
  const st = el.stroke || {};
  const pc = st.penColor ?? 0, pt = st.penType ?? 0;
  const pts = st.points;
  let n = 0;
  try { n = (pts && pts.size) ? await pts.size() : 0; } catch {}
  if (n <= 0) return `${pc}_${pt}|0`;
  const STEPS = Math.min(9, n);
  const idxs = [];
  for (let k = 0; k < STEPS; k++) idxs.push(Math.round(k * (n - 1) / (STEPS - 1 || 1)));
  const coords = [];
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  let last = -1;
  for (const i of idxs) {
    if (i === last) continue; last = i;
    try {
      const p = await pts.get(i);
      if (p) {
        const x = Math.round(p.x), y = Math.round(p.y);
        coords.push(`${x},${y}`);
        if (x < minX) minX = x; if (x > maxX) maxX = x;
        if (y < minY) minY = y; if (y > maxY) maxY = y;
      }
    } catch {}
  }
  return `${pc}_${pt}|${n}|${coords.join(';')}|${minX},${minY},${maxX},${maxY}`;
}

// CustomColorPalette sidecar: {export}/.ccp/{base}_colors.json → {byGeom,byUuid,byIndex,penPrefs}.
async function readSidecar(renderer, exportDir, baseName) {
  const out = { byIndex: {}, byUuid: {}, byGeom: {}, penPrefs: { pen: null, high: null } };
  try {
    const raw = await renderer.readFile(`${exportDir.replace(/\/+$/,'')}/.ccp/${baseName}_colors.json`);
    if (raw) {
      const d = JSON.parse(raw);
      if (d.byUuid)  out.byUuid  = d.byUuid;
      if (d.byIndex) out.byIndex = d.byIndex;
      if (d.byGeom)  out.byGeom  = d.byGeom;
      if (d.penPrefs?.pen)  out.penPrefs.pen  = d.penPrefs.pen;
      if (d.penPrefs?.high) out.penPrefs.high = d.penPrefs.high;
    }
  } catch {}
  // Geom-era sidecar? If so, byIndex resolution is gated off (see resolveColor).
  out.hasGeom = Object.keys(out.byGeom).length > 0;
  return out;
}

// Per-book export-state snapshot for the "new annotations" mode.
// Export state is per-FORMAT: "new annotations" since the last PDF export and
// since the last PNG export are tracked independently, so exporting one format
// never consumes the other's "new" pages.
function exportStatePath(exportDir, baseName, format) {
  return `${exportDir.replace(/\/+$/,'')}/.ccp/${baseName}_exportstate_${format}.json`;
}
async function readExportState(renderer, exportDir, baseName, format) {
  const out = { lastExport: 0, pages: {} };
  try {
    const raw = await renderer.readFile(exportStatePath(exportDir, baseName, format));
    if (raw) {
      const d = JSON.parse(raw);
      if (typeof d.lastExport === 'number') out.lastExport = d.lastExport;
      if (d.pages && typeof d.pages === 'object') out.pages = d.pages;
    }
  } catch {}
  return out;
}
async function writeExportState(renderer, exportDir, baseName, format, state) {
  try { await renderer.writeFile(exportStatePath(exportDir, baseName, format), JSON.stringify(state)); } catch {}
}
async function pageElementCount(notePath, page) {
  const r = unpack(await settle(PluginFileAPI.getElementCounts(notePath, page)).then(x => x.val)).val;
  if (typeof r === 'number') return r;
  if (r && typeof r === 'object') { let s = 0; for (const v of Object.values(r)) if (typeof v === 'number') s += v; return s; }
  return 0;
}

// ─── Per-stroke colour resolution (shared by all document types) ──────────────
// geomKey (optional) is the durable geometry fingerprint — tried FIRST so colours
// survive note editing. byIndex is kept as a fallback for sidecars written before
// geomKey existed (and as a safety net if the fingerprint ever fails to match).
function resolveColor(el, page, sidecar, geomKey) {
  const stroke = el.stroke || {};
  const penColor = stroke.penColor ?? 0;
  const penType  = stroke.penType  ?? 1;
  const uuid     = el.uuid ?? '';
  const idxKey   = `${page}_${el.numInPage}`;
  // Resolution order: geometry (durable + unique) → uuid (usually dead) → ARGB.
  // byIndex (page_numInPage) is DELIBERATELY GATED OFF whenever the sidecar carries
  // byGeom: index drifts/reuses, so it would bleed a colour onto an UNCOLOURED
  // stroke whose export index happens to match a coloured stroke's recorded index.
  // It's used ONLY for pre-geom (legacy) sidecars that have no byGeom at all.
  let colorHex = null, via = '';
  if (geomKey && sidecar.byGeom[geomKey]) { colorHex = sidecar.byGeom[geomKey]; via = 'g'; }
  else if (uuid && sidecar.byUuid[uuid])  { colorHex = sidecar.byUuid[uuid];    via = 'u'; }
  else if (!sidecar.hasGeom && sidecar.byIndex[idxKey]) { colorHex = sidecar.byIndex[idxKey]; via = 'i'; }
  else if (isArgbColor(penColor))         { colorHex = argbToHex(penColor);     via = 'a'; }
  const isHigh = !!colorHex && WASH_PEN_TYPES.has(penType) && isHighlightColor(colorHex);
  return { colorHex, isHigh, penType, via };
}

// ─── Build overlay data per page ──────────────────────────────────────────────

// DOCUMENTS (PDF/EPUB): coloured contour polygons drawn on top of the rendered
// page. Contours are pixel coords, so printed text is never recoloured.
async function buildDocShapes(elements, page, sidecar, drawUncolored, xform = null) {
  const docShapes = []; let totalStrokes = 0, coloredCount = 0;
  // Raw contour extent (pre-transform) — logged once per page so a landscape
  // export reveals exactly what coordinate space contoursSrc are in.
  let rawMinX = Infinity, rawMinY = Infinity, rawMaxX = -Infinity, rawMaxY = -Infinity, rawPts = 0;
  const hasGeom = sidecar.byGeom && Object.keys(sidecar.byGeom).length > 0;
  for (const el of elements) {
    if (el.type !== 0 || !el.stroke) { el.recycle?.(); continue; }
    totalStrokes++;
    // Compute the durable geometry key only when the sidecar carries byGeom (i.e.
    // it was written by a geom-aware CCP); skip the point reads otherwise.
    const geomKey = hasGeom ? await strokeGeomKey(el) : '';
    const { colorHex, isHigh, penType } = resolveColor(el, page, sidecar, geomKey);
    if (colorHex) coloredCount++;

    // NOTES (drawUncolored=false): the base render (generateNotePng) already
    // shows every stroke in grayscale, so we only overlay the COLOURED ones.
    // DOCS (drawUncolored=true): the base has no ink, so every annotation must be
    // drawn — uncoloured marker → neutral light-grey wash, uncoloured pen → its
    // NATIVE grey level (not forced black, so light/dark grey render correctly).
    if (!colorHex && !drawUncolored) { el.recycle?.(); continue; }
    const isMarker = WASH_PEN_TYPES.has(penType);
    const drawColor = colorHex || (isMarker ? '#C9C9C9' : greyFromPenColor(el.stroke.penColor));
    // FORCE: any MARKER stroke renders as a translucent wash, whatever its colour
    // (not just the 6 highlighter shades) — so the underlying content is always
    // visible through a highlight. Non-marker pens stay opaque.
    const wash = isMarker;

    const polys = [];
    try {
      const cs = el.contoursSrc;
      const nC = (cs && cs.size) ? await cs.size() : 0;
      for (let ci = 0; ci < nC; ci++) {
        const poly = await cs.get(ci);
        if (Array.isArray(poly) && poly.length >= 3) {
          polys.push(poly.map(p => {
            if (p.x < rawMinX) rawMinX = p.x; if (p.x > rawMaxX) rawMaxX = p.x;
            if (p.y < rawMinY) rawMinY = p.y; if (p.y > rawMaxY) rawMaxY = p.y; rawPts++;
            const q = xform ? xform(p) : p;       // rotate into the base's space if needed
            return { x: Math.round(q.x), y: Math.round(q.y) };
          }));
        }
      }
    } catch {}
    el.recycle?.();
    if (polys.length) docShapes.push({ color: drawColor, wash, polys });
  }
  // Annotation pixel extent — used by the (currently DISABLED) off-page→landscape
  // path in colorDocPage. Kept for future improvement.
  const annMaxX = rawPts > 0 && xform == null ? Math.round(rawMaxX) : 0;
  const annMaxY = rawPts > 0 && xform == null ? Math.round(rawMaxY) : 0;
  return { docShapes, totalStrokes, coloredCount, annMaxX, annMaxY };
}

// ─── Colour one page (per document type) ──────────────────────────────────────

// Notes render the same way as docs now (contour fill on top of the device page),
// which avoids reading every stroke's sample points. The note base PNG already
// contains the strokes in grayscale, so we overlay only the COLOURED contours
// (drawUncolored=false) — opaque pen / translucent marker wash cover the ink.
async function colorNotePage(renderer, notePath, page, size, sidecar, contentPng, outPng) {
  const r = unpack(await settle(PluginFileAPI.generateNotePng({ notePath, page, times: 1, pngPath: contentPng, type: 1 })).then(x => x.val));
  if (!r.ok) return { ok: false, totalStrokes: 0, coloredCount: 0, err: r.err };

  // Map stroke contours into the base PNG's pixel frame so colour lands on the
  // ink for ANY frame — standard portrait, `times`-scaled, extended mind-map
  // canvas, OR a rotated landscape render. We never assume contour pixels == base
  // pixels: measure BOTH frames (size = getPageSize; pngInfo = what generateNotePng
  // actually rendered) and map between them.
  const info = unpack(await settle(renderer.pngInfo(contentPng)).then(x => x.val)).val;
  const baseW = info?.width ?? 0, baseH = info?.height ?? 0;
  const pageW = size?.width ?? 0, pageH = size?.height ?? 0;

  let xform = null;
  // Scale contours from the page frame (getPageSize) into the base frame (what
  // generateNotePng actually rendered) when they differ uniformly — handles
  // `times` scaling and any same-orientation size difference. A genuine landscape
  // orientation flip is a separate, SDK-limited problem (no rotation info), so we
  // overlay directly there rather than guess a transform.
  if (baseW > 0 && baseH > 0 && pageW > 0 && pageH > 0 &&
      (baseW >= baseH) === (pageW >= pageH) && (baseW !== pageW || baseH !== pageH)) {
    const sx = baseW / pageW, sy = baseH / pageH;
    xform = (p) => ({ x: p.x * sx, y: p.y * sy });
  }

  const elems = unpack(await settle(PluginFileAPI.getElements(page, notePath)).then(x => x.val));
  const elements = Array.isArray(elems.val) ? elems.val : [];
  const { docShapes, totalStrokes, coloredCount } = await buildDocShapes(elements, page, sidecar, false, xform);
  await renderer.drawColoredShapes(contentPng, docShapes, outPng);
  await settle(FileUtils.deleteFile(contentPng));
  return { ok: true, totalStrokes, coloredCount };
}

async function colorDocPage(renderer, notePath, page, size, sidecar, contentPng, outPng, renderBase) {
  const base = await renderBase(contentPng, size);
  if (!base.ok) return { ok: false, totalStrokes: 0, coloredCount: 0, err: base.err };
  const elems = unpack(await settle(PluginFileAPI.getElements(page, notePath)).then(x => x.val));
  const elements = Array.isArray(elems.val) ? elems.val : [];
  const { docShapes, totalStrokes, coloredCount, annMaxX, annMaxY } = await buildDocShapes(elements, page, sidecar, true);

  // ── OFF-PAGE → LANDSCAPE (DISABLED — kept for future improvement) ───────────
  // When a document is edited in landscape, annotations can run past the portrait
  // page's right edge and get clipped on export. This block detects that and
  // re-renders the base on a landscape canvas. It is OFF because the only render
  // call available, renderDocPage(w,h), STRETCHES a portrait PDF to fill the
  // landscape canvas (distorted) and the overlaid colours came out wrong.
  // TODO to revive: render the PDF at its NATIVE scale/aspect (no stretch) onto a
  //   wider canvas — e.g. a renderDocPage that preserves aspect + letterboxes, or
  //   render portrait then pad width — so the overlay aligns and colours stay true.
  // Reliable workflow today: rotate the device back to PORTRAIT before exporting
  // (the device reflows annotations to fit the page on its own).
  const OFFPAGE_LANDSCAPE_ENABLED = false;
  const PAD = 8;
  if (OFFPAGE_LANDSCAPE_ENABLED && (annMaxX > size.width + PAD || annMaxY > size.height + PAD)) {
    const landW = Math.max(size.height, annMaxX + PAD);
    const landH = Math.max(size.width,  annMaxY + PAD);
    console.log(`ECP doc off-page p${page}: annot=${annMaxX}x${annMaxY} page=${size.width}x${size.height} → landscape ${landW}x${landH}`);
    const lb = await renderBase(contentPng, { width: landW, height: landH });
    if (lb.ok) {
      await renderer.drawColoredShapes(contentPng, docShapes, outPng);
      await settle(FileUtils.deleteFile(contentPng));
      return { ok: true, totalStrokes, coloredCount };
    }
  }

  // drawColoredShapes with an empty array just copies content → out.
  await renderer.drawColoredShapes(contentPng, docShapes, outPng);
  await settle(FileUtils.deleteFile(contentPng));
  return { ok: true, totalStrokes, coloredCount };
}

// ─── Document-type detection + page bookkeeping ───────────────────────────────

function detectKind(notePath) {
  if (/\.note$/i.test(notePath)) return 'note';
  if (/\.pdf$/i.test(notePath))  return 'pdf';
  return 'doc';   // EPUB and other DOC-app formats → generateDocImage
}

async function resolveTotal(kind, notePath) {
  let total;
  if (kind === 'note') {
    total = unpack(await settle(PluginFileAPI.getNoteTotalPageNum(notePath)).then(r => r.val)).val;
  } else {
    total = unpack(await settle(PluginDocAPI.getCurrentTotalPages()).then(r => r.val)).val;
    if (typeof total !== 'number' || total < 1) {
      total = unpack(await settle(PluginFileAPI.getNoteTotalPageNum(notePath)).then(r => r.val)).val;
    }
  }
  return (typeof total === 'number' && total > 0) ? total : null;
}

// Annotated pages = pages that actually have ≥1 annotation element right now.
// Documents expose a mark layer (getMarkPages) to narrow the candidates; notes
// don't, so we scan every page. IMPORTANT: getMarkPages still lists a page after
// its annotations were ERASED (the empty mark layer lingers), so we must confirm
// each candidate truly has elements — otherwise erased pages get exported blank.
async function resolveAnnotatedPages(kind, notePath, total) {
  let candidates = null;
  if (kind !== 'note') {
    const marks = unpack(await settle(PluginFileAPI.getMarkPages(notePath)).then(r => r.val)).val;
    if (Array.isArray(marks) && marks.length) candidates = [...new Set(marks)].sort((a, b) => a - b);
  }
  if (!candidates) candidates = Array.from({ length: total }, (_, i) => i);

  const pages = [];
  for (const p of candidates) { if (await pageElementCount(notePath, p) > 0) pages.push(p); }
  return pages;
}

// ─── Public: export a colour PDF (one PDF page per document page) ─────────────

/**
 * @param {object}   opts
 * @param {'full'|'annotated'|'new'} opts.mode  page scope.
 * @param {function} [opts.onProgress]   (done, total) callback.
 */
// Parse a user page spec — "5", "3-10", or a comma list like "3-10, 15" — into
// 0-based page indices. User-facing page numbers are 1-based (matches the rest
// of the UI), so we subtract 1. Out-of-range numbers are dropped.
function parsePageSpec(spec, total) {
  const want = new Set();
  for (const partRaw of String(spec || '').split(',')) {
    const part = partRaw.trim();
    if (!part) continue;
    const range = part.match(/^(\d+)\s*-\s*(\d+)$/);
    if (range) {
      let a = parseInt(range[1], 10), b = parseInt(range[2], 10);
      if (a > b) { const t = a; a = b; b = t; }
      for (let p = a; p <= b; p++) want.add(p);
    } else if (/^\d+$/.test(part)) {
      want.add(parseInt(part, 10));
    } else {
      throw new Error(`Couldn't read "${part}". Use a page like 5 or a range like 3-10.`);
    }
  }
  const pages = [...want].filter(p => p >= 1 && p <= total).sort((a, b) => a - b).map(p => p - 1);
  if (pages.length === 0) throw new Error(`No valid pages in "${spec}". This document has ${total} page(s).`);
  return pages;
}

export async function runExport({ mode = 'full', format = 'pdf', pngMode = 'perPage', pageSpec = '', onProgress } = {}) {
  const renderer = NativeModules.CombinedColorPdfRenderer;
  if (!renderer || !renderer.drawColoredShapes || !renderer.overlayColoredStrokes || !renderer.assemblePdf) {
    throw new Error('CombinedColorPdfRenderer native module not found. Is the plugin installed correctly?');
  }
  if (format === 'png' && pngMode === 'combined' && !renderer.stitchPngVertical) {
    throw new Error('This plugin build does not support combined PNG — reinstall the latest version.');
  }

  const exportDir = await FileUtils.getExportPath();
  if (!exportDir) throw new Error('Cannot resolve EXPORT directory');
  await FileUtils.makeDir(exportDir);
  const EXPORT = exportDir.replace(/\/+$/, '');

  const notePath = unpack(await PluginCommAPI.getCurrentFilePath()).val;
  if (!notePath) throw new Error('getCurrentFilePath failed — open a document first');
  const baseName = deriveBaseName(notePath);
  const kind = detectKind(notePath);

  const total = await resolveTotal(kind, notePath);
  if (total == null) throw new Error('Could not determine page count');

  // Resolve the page list for the chosen mode.
  let pages;
  if (mode === 'full') {
    let t = total;
    if (MAX_PAGES > 0 && t > MAX_PAGES) t = MAX_PAGES;
    pages = Array.from({ length: t }, (_, i) => i);
  } else if (mode === 'current') {
    const cur = unpack(await settle(PluginCommAPI.getCurrentPageNum()).then(x => x.val)).val;
    if (typeof cur !== 'number' || cur < 0 || cur >= total) throw new Error('Could not determine the current page.');
    pages = [cur];
  } else if (mode === 'pages') {
    pages = parsePageSpec(pageSpec, total);   // user-specified pages/ranges (1-based)
  } else {
    const annotated = await resolveAnnotatedPages(kind, notePath, total);
    if (mode === 'new') {
      const state = await readExportState(renderer, EXPORT, baseName, format);
      pages = [];
      for (const p of annotated) {
        const count = await pageElementCount(notePath, p);
        const prev = state.pages[String(p)];
        if (prev == null || count > prev) pages.push(p);
      }
      if (pages.length === 0) throw new Error('No pages with new annotations since your last export of this book.');
    } else {
      pages = annotated;
      if (pages.length === 0) throw new Error('No annotated pages found on this document.');
    }
  }

  // Combined PNG is one tall image — capped so it can't OOM the device.
  const COMBINED_PNG_MAX = 25;
  if (format === 'png' && pngMode === 'combined' && pages.length > COMBINED_PNG_MAX) {
    throw new Error(`Combined PNG is limited to ${COMBINED_PNG_MAX} pages — you selected ${pages.length}. Pick a narrower scope, or choose “one PNG per page” or PDF.`);
  }

  const sidecar = await readSidecar(renderer, EXPORT, baseName);

  // Notes must be flushed to disk before generateNotePng/getElements.
  if (kind === 'note') { try { await PluginNoteAPI.saveCurrentNote(); } catch {} }

  const stamp = Date.now();
  const pluginDir = await PluginManager.getPluginDirPath();
  const tmpDir = `${(pluginDir || EXPORT).replace(/\/+$/, '')}/cpdf-${stamp}`;
  await FileUtils.makeDir(tmpDir);

  // PNG "one per page" writes its page images straight into a kept EXPORT
  // subfolder so they survive tmp cleanup; PDF and combined-PNG render to tmp
  // and are assembled/stitched, then cleaned up.
  const keepPages = format === 'png' && pngMode === 'perPage';
  const pngOutDir = `${EXPORT}/color_${baseName}_${mode}_${stamp}`;
  if (keepPages) await FileUtils.makeDir(pngOutDir);

  const pagePngPaths = [];
  let totalStrokes = 0, coloredCount = 0, skipped = 0, done = 0;

  try {
    for (const page of pages) {
      const sz = unpack(await settle(PluginFileAPI.getPageSize(notePath, page)).then(r => r.val));
      // size: resolved-with-fallback (docs need concrete dims to render the base).
      // pageSizeExact: the TRUE page frame, or null if getPageSize failed — notes
      // use this to map contours into the base frame without trusting a fallback.
      const pageSizeExact = (sz.ok && sz.val?.width) ? sz.val : null;
      const size = pageSizeExact || { width: 1404, height: 1872 };

      const contentPng = `${tmpDir}/base-${String(page).padStart(4, '0')}.png`;
      const outPng      = keepPages
        ? `${pngOutDir}/p${String(page + 1).padStart(4, '0')}.png`   // 1-based page numbering
        : `${tmpDir}/page-${String(page).padStart(4, '0')}.png`;

      let r;
      if (kind === 'note') {
        r = await colorNotePage(renderer, notePath, page, pageSizeExact, sidecar, contentPng, outPng);
      } else if (kind === 'pdf') {
        r = await colorDocPage(renderer, notePath, page, size, sidecar, contentPng, outPng,
          async (png, s) => { const x = await settle(renderer.renderDocPage(notePath, page, s.width, s.height, png)); return { ok: x.ok, err: x.err }; });
      } else {
        r = await colorDocPage(renderer, notePath, page, size, sidecar, contentPng, outPng,
          async (png, s) => { const x = unpack(await settle(PluginDocAPI.generateDocImage(notePath, page, png, s)).then(y => y.val)); return { ok: x.ok && x.val !== false, err: x.err }; });
      }

      done++;
      onProgress?.(done, pages.length);
      if (!r.ok) { skipped++; await settle(FileUtils.deleteFile(contentPng)); continue; }
      totalStrokes += r.totalStrokes;
      coloredCount += r.coloredCount;
      pagePngPaths.push(outPng);
    }

    if (pagePngPaths.length === 0) throw new Error('No pages rendered.');

    let outPath;
    if (format === 'png' && pngMode === 'combined') {
      outPath = `${EXPORT}/color_${baseName}_${mode}_${stamp}.png`;
      await renderer.stitchPngVertical(pagePngPaths, outPath);
    } else if (keepPages) {
      outPath = pngOutDir;   // a folder containing one PNG per page
    } else {
      outPath = `${EXPORT}/color_${baseName}_${mode}_${stamp}.pdf`;
      await renderer.assemblePdf(pagePngPaths, outPath);
    }

    // Refresh the "new annotations" baseline for every currently-annotated page.
    // Skipped for ad-hoc specific-page exports so they don't consume the
    // "pages with new annotations" tracking.
    if (mode !== 'pages' && mode !== 'current') {
      try {
        const annotatedNow = await resolveAnnotatedPages(kind, notePath, total);
        const snapshot = { lastExport: stamp, pages: {} };
        for (const p of annotatedNow) snapshot.pages[String(p)] = await pageElementCount(notePath, p);
        await writeExportState(renderer, EXPORT, baseName, format, snapshot);
      } catch {}
    }

    return { path: outPath, pages: pagePngPaths.length, totalStrokes, coloredCount, skipped, mode, kind, format, pngMode };

  } finally {
    // Keep the per-page PNGs (they're the deliverable); always clear the temp dir.
    if (!keepPages) { for (const p of pagePngPaths) { try { await FileUtils.deleteFile(p); } catch {} } }
    try { await FileUtils.deleteDir(tmpDir); } catch {}
  }
}
