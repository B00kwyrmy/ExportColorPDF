#!/usr/bin/env bash
# Build ColorExport.snplg
set -e
echo "Installing dependencies…"
npm install
echo "Building plugin…"
npx react-native bundle \
  --platform android \
  --dev false \
  --entry-file index.js \
  --bundle-output build/outputs/index.android.bundle \
  --assets-dest build/outputs/res
mkdir -p build/outputs
cp PluginConfig.json build/outputs/
cd build/outputs
zip -r "ColorExport.snplg" . -x "*.snplg"
echo "Done → build/outputs/ColorExport.snplg"
