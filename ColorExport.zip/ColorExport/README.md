# Color Export — Supernote Plugin

A plugin for the Supernote NOTE app that scans every element in the current note (all pages) and produces a plain-text color report listing the hex color value assigned to each stroke, shape, text box, geometry element, and more. Run this before or after any note / digest / atelier export to capture a full color record.

## What it produces

```
=== Color Export: MyNote.note ===
Generated: 2026-05-17

--- Page 1 ---
  Element 1 | Stroke    | #231F20
  Element 2 | Geometry  | #FF8200
  Element 3 | TextBox   | #0033A0

--- Summary (by color) ---
  #0033A0  |     1 element(s)
  #231F20  |    12 element(s)
  #FF8200  |     3 element(s)

=== End of Color Export ===
```

## Requirements

- Node.js 18 or later
- Android SDK with `adb` in your PATH
- PowerShell (Windows) or Bash (macOS / Linux)
- React Native 0.79.2 (pinned — other versions may be incompatible with PluginHost)

## Build

```bash
npm install
bash buildPlugin.sh
```

Output: `build/outputs/ColorExport.snplg`

## Deploy

```bash
adb push build/outputs/ColorExport.snplg /storage/emulated/0/MyStyle/
```

Then on the device: **Settings → Apps → Plugins → Install**.

## Debug

```bash
adb logcat -c
# trigger an action on device, then:
adb logcat -d -s ReactNativeJS:V
```

## How it works

The plugin registers an **Export Colors** toolbar button in the NOTE app. When tapped it:

1. Calls `PluginNoteAPI.saveCurrentNote()` to flush in-memory state.
2. Gets the total page count via `getNoteTotalPageNum()`.
3. For each page: calls `getElementCounts()` then `getElement()` for every index.
4. Reads `element.type` and `element.color` (Android ARGB integer), converts to hex.
5. Calls `element.recycle()` after each read to free native memory.
6. Builds a plain-text report and surfaces it via the Android Share sheet.

## Known limitations

- Pictures and FiveStar elements may report `#000000` if the SDK returns 0 for their color field.
- There are no SDK hooks into the digest or atelier export pipeline; run this plugin manually before triggering those exports.

## License

MIT
