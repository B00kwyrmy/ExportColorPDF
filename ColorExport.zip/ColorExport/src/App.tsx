import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { PluginCommAPI, PluginFileAPI, PluginManager, PluginNoteAPI } from 'sn-plugin-lib';
import { checkPendingButton } from '../index';

// ─── Types ───────────────────────────────────────────────────────────────────

// Element type codes used by the Supernote SDK
const ELEMENT_TYPE_NAMES: Record<number, string> = {
  1: 'Stroke',
  2: 'Title',
  3: 'Link',
  4: 'TextBox',
  5: 'Geometry',
  6: 'Picture',
  7: 'FiveStar',
};

interface ElementColorRecord {
  elementIndex: number;
  typeName: string;
  hexColor: string;
  argbInt: number;
}

interface PageColorRecord {
  pageNumber: number;
  elements: ElementColorRecord[];
}

interface ColorReport {
  noteFileName: string;
  exportDate: string;
  pages: PageColorRecord[];
  summary: { hex: string; count: number; typeName: string }[];
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function argbIntToHex(argb: number): string {
  const unsigned = argb >>> 0;
  const r = (unsigned >> 16) & 0xff;
  const g = (unsigned >> 8) & 0xff;
  const b = unsigned & 0xff;
  return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`.toUpperCase();
}

function fileNameFromPath(path: string): string {
  const parts = path.replace(/\\/g, '/').split('/');
  return parts[parts.length - 1] ?? path;
}

function formatReport(report: ColorReport): string {
  const lines: string[] = [];
  lines.push(`=== Color Export: ${report.noteFileName} ===`);
  lines.push(`Generated: ${report.exportDate}`);
  lines.push('');

  for (const page of report.pages) {
    lines.push(`--- Page ${page.pageNumber} ---`);
    if (page.elements.length === 0) {
      lines.push('  (no elements with color data)');
    } else {
      for (const el of page.elements) {
        lines.push(`  Element ${el.elementIndex + 1} | ${el.typeName.padEnd(9)} | ${el.hexColor}`);
      }
    }
    lines.push('');
  }

  lines.push('--- Summary (by color) ---');
  for (const entry of report.summary) {
    lines.push(`  ${entry.hex}  |  ${String(entry.count).padStart(4)} element(s)`);
  }
  lines.push('');
  lines.push('=== End of Color Export ===');

  return lines.join('\n');
}

function buildSummary(pages: PageColorRecord[]): { hex: string; count: number; typeName: string }[] {
  const counts: Record<string, number> = {};
  for (const page of pages) {
    for (const el of page.elements) {
      counts[el.hexColor] = (counts[el.hexColor] ?? 0) + 1;
    }
  }
  return Object.entries(counts)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([hex, count]) => ({ hex, count, typeName: '' }));
}

// ─── Component ───────────────────────────────────────────────────────────────

export default function App(): React.JSX.Element {
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState('');
  const [report, setReport] = useState<ColorReport | null>(null);
  const [reportText, setReportText] = useState<string>('');
  const [error, setError] = useState<string>('');

  // Consume pending button on mount
  useEffect(() => {
    checkPendingButton();
  }, []);

  const runScan = async () => {
    setScanning(true);
    setReport(null);
    setReportText('');
    setError('');

    try {
      // Resolve the current note file path
      const fileResp = await PluginCommAPI.getCurrentFilePath();
      if (!fileResp.success || !fileResp.result) {
        setError('Could not determine current file path.');
        setScanning(false);
        return;
      }
      const filePath: string = fileResp.result;
      const noteFileName = fileNameFromPath(filePath);

      setProgress(`Scanning ${noteFileName}…`);

      // Persist in-memory state before reading
      await PluginNoteAPI.saveCurrentNote();

      // Get total page count
      const totalPagesResp = await PluginNoteAPI.getNoteTotalPageNum(filePath);
      if (!totalPagesResp.success || !totalPagesResp.result) {
        setError('Could not get page count.');
        setScanning(false);
        return;
      }
      const totalPages: number = totalPagesResp.result;

      const pages: PageColorRecord[] = [];

      for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
        setProgress(`Scanning page ${pageNum} of ${totalPages}…`);

        // Get element count for this page
        const countResp = await PluginFileAPI.getElementCounts(pageNum, filePath);
        if (!countResp.success || !countResp.result) {
          pages.push({ pageNumber: pageNum, elements: [] });
          continue;
        }

        const elementCount: number = countResp.result;
        const pageRecord: PageColorRecord = { pageNumber: pageNum, elements: [] };

        for (let idx = 0; idx < elementCount; idx++) {
          // getElement puts filePath first for write-like access
          const elResp = await PluginFileAPI.getElement(filePath, pageNum, idx);
          if (!elResp.success || !elResp.result) continue;

          const el = elResp.result;
          const typeName = ELEMENT_TYPE_NAMES[el.type] ?? `Type${el.type}`;
          const hexColor = argbIntToHex(el.color);

          pageRecord.elements.push({
            elementIndex: idx,
            typeName,
            hexColor,
            argbInt: el.color,
          });

          // Always recycle to free native-side memory
          el.recycle();
        }

        pages.push(pageRecord);
      }

      const summary = buildSummary(pages);
      const exportDate = new Date().toISOString().slice(0, 10);

      const colorReport: ColorReport = {
        noteFileName,
        exportDate,
        pages,
        summary,
      };

      const text = formatReport(colorReport);
      setReport(colorReport);
      setReportText(text);
      setProgress('');
    } catch (err: any) {
      setError(`Scan error: ${err?.message ?? String(err)}`);
    } finally {
      setScanning(false);
    }
  };

  const shareReport = async () => {
    if (!reportText) return;
    try {
      await Share.share({
        message: reportText,
        title: report ? `Color Export — ${report.noteFileName}` : 'Color Export',
      });
    } catch (err: any) {
      setError(`Share failed: ${err?.message ?? String(err)}`);
    }
  };

  const close = () => PluginManager.closePluginView();

  return (
    <View style={styles.root}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Color Export</Text>
        <TouchableOpacity style={styles.closeBtn} onPress={close}>
          <Text style={styles.closeBtnText}>Close</Text>
        </TouchableOpacity>
      </View>

      {/* Description */}
      {!report && !scanning && (
        <View style={styles.descBox}>
          <Text style={styles.descText}>
            Scans every element in the current note and records the hex color assigned to each stroke, shape,
            text box, geometry, and other element type. Run this before or after any note / digest / atelier
            export to capture the full color record.
          </Text>
        </View>
      )}

      {/* Scanning state */}
      {scanning && (
        <View style={styles.progressBox}>
          <ActivityIndicator size="large" color="#000000" />
          <Text style={styles.progressText}>{progress}</Text>
        </View>
      )}

      {/* Error */}
      {!!error && (
        <View style={styles.errorBox}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}

      {/* Report */}
      {report && !scanning && (
        <>
          <View style={styles.summaryHeader}>
            <Text style={styles.summaryTitle}>
              {report.noteFileName} — {report.pages.length} page(s)
            </Text>
            <TouchableOpacity style={styles.shareBtn} onPress={shareReport}>
              <Text style={styles.shareBtnText}>Share / Save</Text>
            </TouchableOpacity>
          </View>

          {/* Summary table */}
          <View style={styles.summaryTable}>
            <Text style={styles.sectionLabel}>Color Summary</Text>
            {report.summary.length === 0 ? (
              <Text style={styles.emptyText}>No colored elements found.</Text>
            ) : (
              report.summary.map(entry => (
                <View key={entry.hex} style={styles.summaryRow}>
                  <View style={[styles.swatchSmall, { backgroundColor: entry.hex }]} />
                  <Text style={styles.summaryHex}>{entry.hex}</Text>
                  <Text style={styles.summaryCount}>{entry.count} element(s)</Text>
                </View>
              ))
            )}
          </View>

          {/* Full report text */}
          <Text style={styles.sectionLabel}>Full Report</Text>
          <ScrollView style={styles.reportScroll}>
            <Text style={styles.reportText}>{reportText}</Text>
          </ScrollView>
        </>
      )}

      {/* Scan button */}
      <TouchableOpacity
        style={[styles.scanBtn, scanning && styles.scanBtnDisabled]}
        onPress={runScan}
        disabled={scanning}
      >
        <Text style={styles.scanBtnText}>
          {scanning ? 'Scanning…' : report ? 'Re-Scan Note' : 'Scan Note Colors'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

// ─── Styles ──────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#000000',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000000',
  },
  closeBtn: {
    borderWidth: 1,
    borderColor: '#000000',
    paddingHorizontal: 14,
    paddingVertical: 6,
  },
  closeBtnText: {
    fontSize: 15,
    color: '#000000',
  },
  descBox: {
    margin: 20,
    padding: 16,
    borderWidth: 1,
    borderColor: '#CCCCCC',
    backgroundColor: '#F8F8F8',
  },
  descText: {
    fontSize: 15,
    color: '#333333',
    lineHeight: 22,
  },
  progressBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  progressText: {
    marginTop: 16,
    fontSize: 16,
    color: '#333333',
  },
  errorBox: {
    margin: 20,
    padding: 12,
    borderWidth: 1,
    borderColor: '#000000',
    backgroundColor: '#F0F0F0',
  },
  errorText: {
    fontSize: 14,
    color: '#000000',
  },
  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#CCCCCC',
  },
  summaryTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#000000',
    flex: 1,
  },
  shareBtn: {
    borderWidth: 1,
    borderColor: '#000000',
    paddingHorizontal: 14,
    paddingVertical: 6,
    marginLeft: 12,
  },
  shareBtnText: {
    fontSize: 14,
    color: '#000000',
  },
  summaryTable: {
    paddingHorizontal: 20,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#CCCCCC',
  },
  sectionLabel: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#555555',
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  emptyText: {
    fontSize: 14,
    color: '#888888',
    paddingVertical: 8,
  },
  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  swatchSmall: {
    width: 24,
    height: 24,
    borderWidth: 1,
    borderColor: '#000000',
    marginRight: 12,
  },
  summaryHex: {
    fontSize: 15,
    fontWeight: '600',
    color: '#000000',
    width: 90,
  },
  summaryCount: {
    fontSize: 14,
    color: '#444444',
  },
  reportScroll: {
    flex: 1,
    marginHorizontal: 20,
    borderWidth: 1,
    borderColor: '#CCCCCC',
    padding: 10,
    marginBottom: 10,
  },
  reportText: {
    fontSize: 12,
    fontFamily: 'monospace',
    color: '#222222',
    lineHeight: 18,
  },
  scanBtn: {
    backgroundColor: '#000000',
    marginHorizontal: 20,
    marginVertical: 14,
    paddingVertical: 16,
    alignItems: 'center',
  },
  scanBtnDisabled: {
    backgroundColor: '#888888',
  },
  scanBtnText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
